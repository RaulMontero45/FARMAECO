﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace FarmaEcoWebApp.Data
{
    public class FarmaEcoWebAppContext : IdentityDbContext<IdentityUser>
    {
        public FarmaEcoWebAppContext(DbContextOptions<FarmaEcoWebAppContext> options)
            : base(options)
        {
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\FARMAECO.mdf;Integrated Security=True");
            }
        }
    }
}
