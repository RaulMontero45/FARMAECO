using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;
using System.Globalization;

namespace FarmaEcoWebApp.Pages
{
    public class FacturadorModel : PageModel
    {
        public int idEmpleado { get; set; } // Define idEmpleado property

        private readonly IConfiguration _configuration;

        public FacturadorModel(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public List<Item> Items { get; set; } = new List<Item>();
        public List<Cliente> Clientes { get; set; } = new List<Cliente>();

        public class Item
        {
            public int Id { get; set; }
            public string Nombre { get; set; }
            public int Existencias { get; set; }
            public decimal Precio { get; set; }
        }

        public class Cliente
        {
            public int Id { get; set; }
            public string Nombre { get; set; }
            public string Telefono { get; set; }
            public string Email { get; set; }
        }

        public decimal Discount { get; set; }

        public async Task OnGetAsync()
        {
            var connectionString = _configuration.GetConnectionString("DefaultConnection");

            // Fetch existing clients from the database
            Clientes = await GetClientesFromDatabase();

            string query = "SELECT idProducto, nombre, existencias, precio FROM INVENTARIO";

            // Fetch items from the database
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                await connection.OpenAsync();

                using (SqlCommand command = new SqlCommand(query, connection))
                using (SqlDataReader reader = await command.ExecuteReaderAsync())
                {
                    while (reader.Read())
                    {
                        int existencias = reader.GetInt32(2);
                        if (existencias > 0)
                        {
                            Items.Add(new Item
                            {
                                Id = reader.GetInt32(0),
                                Nombre = reader.GetString(1),
                                Existencias = existencias,
                                Precio = reader.GetDecimal(3)
                            });
                        }
                    }
                }
            }
        }

        public async Task<IActionResult> OnPostAsync(Dictionary<int, int> cantidad, string descuentoCodigo, string metodo, string cliente, string nombreCliente, string telefono, string email)
        {
            // Validate required fields
            if (string.IsNullOrEmpty(metodo))
            {
                ModelState.AddModelError("", "El m�todo es obligatorio.");
                return Page();
            }

            // Extract clienteId from cliente parameter or handle nuevo case
            int clienteId = 0;
            if (cliente == "nuevo")
            {
                // Create a new client entry in the CLIENTS table
                Cliente newCliente = new Cliente
                {
                    Nombre = nombreCliente,
                    Telefono = telefono,
                    Email = email
                };

                // Save the new client to the database
                clienteId = await CreateNewClienteAsync(newCliente);
            }
            else if (!string.IsNullOrEmpty(cliente))
            {
                string[] clienteParts = cliente.Split('-');
                if (clienteParts.Length == 2 && int.TryParse(clienteParts[0], out clienteId))
                {
                    // Successfully extracted clienteId
                }
                else
                {
                    ModelState.AddModelError("", "El cliente seleccionado no es v�lido.");
                    return Page();
                }
            }

            // Fetch discount from the database based on the discount code
            decimal? discount = null;
            if (!string.IsNullOrEmpty(descuentoCodigo))
            {
                discount = await GetDiscountFromDatabase(descuentoCodigo);
                if (discount == null)
                {
                    ModelState.AddModelError("", "El c�digo de descuento no es v�lido.");
                    return Page();
                }
            }

            // Validate and convert descuentoCodigo to an integer if necessary
            int idDescuento = 0;
            if (!string.IsNullOrEmpty(descuentoCodigo))
            {
                if (!int.TryParse(descuentoCodigo, NumberStyles.Integer, CultureInfo.InvariantCulture, out idDescuento))
                {
                    ModelState.AddModelError("", "El c�digo de descuento debe ser un n�mero v�lido.");
                    return Page();
                }
            }

            // Calculate subtotal
            decimal subtotal = 0;
            foreach (var kvp in cantidad)
            {
                var item = Items.FirstOrDefault(i => i.Id == kvp.Key);
                if (item != null)
                {
                    subtotal += item.Precio * kvp.Value;
                }
            }

            // Apply discount
            decimal? descuento = (discount.HasValue && discount.Value > 0) ? discount.Value * subtotal / 100 : (decimal?)null;

            // Calculate total
            decimal total = subtotal - (descuento ?? 0); // Use 0 if descuento is null
            decimal impuesto = total * 0.13m; // 13% tax

            // Create entry in FACTURAS table
            int idFactura = await CreateFacturaAsync(idEmpleado, idDescuento, descuento, impuesto, total, clienteId, metodo, subtotal);

            // Subtract quantity of items selected from existencias in INVENTARIO table
            foreach (var kvp in cantidad)
            {
                await UpdateExistenciasAsync(kvp.Key, kvp.Value);

                // Add entry to MOVIMIENTOS table
                await CreateMovimientoAsync(idFactura, kvp.Key, -kvp.Value);
            }

            // Redirect to refresh the page
            return RedirectToPage("/Facturador");
        }
        private async Task<int> CreateNewClienteAsync(Cliente newCliente)
        {
            var connectionString = _configuration.GetConnectionString("DefaultConnection");
            string query = "INSERT INTO CLIENTS (nombre, telefono, email) " +
                           "VALUES (@nombre, @telefono, @email); " +
                           "SELECT SCOPE_IDENTITY();"; // Return the ID of the newly inserted row

            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@nombre", newCliente.Nombre);
                command.Parameters.AddWithValue("@telefono", newCliente.Telefono);
                command.Parameters.AddWithValue("@email", newCliente.Email);

                await connection.OpenAsync();

                // Execute the query and return the ID of the newly inserted row
                return Convert.ToInt32(await command.ExecuteScalarAsync());
            }
        }

        private async Task<int> CreateFacturaAsync(int idEmpleado, int idDescuento, decimal? descuento, decimal impuesto, decimal total, int clienteId, string metodo, decimal Subtotal)
        {
            var connectionString = _configuration.GetConnectionString("DefaultConnection");
            string query = "INSERT INTO FACTURAS (idEmpleado, idCliente, Subtotal, idDescuento, Descuento, Impuesto, Total, Metodo, Fecha) " +
                           "VALUES (@idEmpleado, @idCliente, @Subtotal, @idDescuento, @descuento, @impuesto, @total, @metodo, @fecha); " +
                           "SELECT SCOPE_IDENTITY();"; // Return the ID of the newly inserted row

            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@idEmpleado", idEmpleado); // Use the idEmpleado parameter
                command.Parameters.AddWithValue("@idCliente", clienteId);
                command.Parameters.AddWithValue("@Subtotal", Subtotal);
                command.Parameters.AddWithValue("@idDescuento", idDescuento);
                command.Parameters.AddWithValue("@descuento", descuento.HasValue ? (object)descuento.Value : DBNull.Value);
                command.Parameters.AddWithValue("@impuesto", impuesto);
                command.Parameters.AddWithValue("@total", total);
                command.Parameters.AddWithValue("@metodo", metodo);
                command.Parameters.AddWithValue("@fecha", DateTime.Now);

                await connection.OpenAsync();

                // Execute the query and return the ID of the newly inserted row
                return Convert.ToInt32(await command.ExecuteScalarAsync());
            }
        }

        private async Task UpdateExistenciasAsync(int idProducto, int cantidad)
        {
            var connectionString = _configuration.GetConnectionString("DefaultConnection");
            string query = "UPDATE INVENTARIO SET existencias = existencias - @cantidad WHERE idProducto = @idProducto";

            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@idProducto", idProducto);
                command.Parameters.AddWithValue("@cantidad", cantidad);

                await connection.OpenAsync();
                await command.ExecuteNonQueryAsync();
            }
        }

        private async Task CreateMovimientoAsync(int idFactura, int idProducto, int cantidad)
        {
            var connectionString = _configuration.GetConnectionString("DefaultConnection");
            string query = "INSERT INTO MOVIMIENTOS (idFactura, idProducto, cantidad) VALUES (@idFactura, @idProducto, @cantidad)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@idFactura", idFactura);
                command.Parameters.AddWithValue("@idProducto", idProducto);
                command.Parameters.AddWithValue("@cantidad", cantidad);

                await connection.OpenAsync();
                await command.ExecuteNonQueryAsync();
            }
        }


        public async Task<IActionResult> OnGetDiscountAsync(string codigo)
        {
            try
            {
                // Call the method to get the discount from the database using the provided codigo
                var discountPercentage = await GetDiscountFromDatabase(codigo);

                // Return the discount percentage as JSON
                return new JsonResult(new { discountPercentage });
            }
            catch (Exception ex)
            {
                // Log the error
                Console.WriteLine($"Error fetching discount from database: {ex.Message}");

                // Return a 500 Internal Server Error response
                return StatusCode(500);
            }
        }

        // New method for fetching clientes from the database
        private async Task<List<Cliente>> GetClientesFromDatabase()
        {
            var clientes = new List<Cliente>();
            var connectionString = _configuration.GetConnectionString("DefaultConnection");

            string query = "SELECT idCliente, nombreCliente FROM CLIENTES";

            // Fetch clients from the database
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                await connection.OpenAsync();

                using (SqlCommand command = new SqlCommand(query, connection))
                using (SqlDataReader reader = await command.ExecuteReaderAsync())
                {
                    while (reader.Read())
                    {
                        clientes.Add(new Cliente
                        {
                            Id = reader.GetInt32(0),
                            Nombre = reader.GetString(1)
                        });
                    }
                }
            }

            return clientes;
        }

        private async Task<decimal> GetDiscountFromDatabase(string discountCode)
        {
            var connectionString = _configuration.GetConnectionString("DefaultConnection");
            string query = "SELECT descuento FROM PROMOCIONES WHERE idPromocion = @codigo";

            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                if (!int.TryParse(discountCode, out int codigo))
                {
                    // Handle invalid discount code format
                    // For example, return a default discount or throw an exception
                    return 0; // or throw new ArgumentException("Invalid discount code format");
                }

                command.Parameters.AddWithValue("@codigo", codigo);

                await connection.OpenAsync();

                var result = await command.ExecuteScalarAsync();

                if (result != null && result != DBNull.Value)
                {
                    return Convert.ToDecimal(result);
                }

                return 0; // If no discount is found, return 0
            }
        }

    }
}
