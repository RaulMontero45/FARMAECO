using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;

namespace FarmaEcoWebApp.Pages
{
    public class InventarioModel : PageModel
    {
        private readonly IConfiguration _configuration;

        public InventarioModel(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public List<InventarioItem> Items { get; set; }

        public async Task<IActionResult> OnGetAsync()
        {
            Items = new List<InventarioItem>();

            try
            {
                var connectionString = _configuration.GetConnectionString("DefaultConnection");

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    await connection.OpenAsync();

                    string query = "SELECT idProducto, idProveedor, nombre, descripcion, existencias, precio FROM INVENTARIO";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    using (SqlDataReader reader = await command.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            Items.Add(new InventarioItem
                            {
                                IdProducto = reader.GetInt32(0),
                                IdProveedor = reader.GetInt32(1),
                                Nombre = reader.GetString(2),
                                Descripcion = reader.GetString(3),
                                Existencias = reader.GetInt32(4),
                                Precio = reader.GetDecimal(5)
                            });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions
                // Log the exception, display an error message, etc.
                Console.WriteLine(ex.Message);
                return StatusCode(500); // Internal Server Error
            }

            return Page();
        }

        public async Task<IActionResult> OnPostAsync(List<InventarioItem> items)
        {
            try
            {
                var connectionString = _configuration.GetConnectionString("DefaultConnection");

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    await connection.OpenAsync();

                    foreach (var item in items)
                    {
                        string query = @"UPDATE INVENTARIO SET 
                                 idProveedor = @IdProveedor, 
                                 nombre = @Nombre, 
                                 descripcion = @Descripcion, 
                                 existencias = @Existencias, 
                                 precio = @Precio 
                                 WHERE idProducto = @IdProducto";

                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@IdProducto", item.IdProducto);
                            command.Parameters.AddWithValue("@IdProveedor", item.IdProveedor);
                            command.Parameters.AddWithValue("@Nombre", item.Nombre);
                            command.Parameters.AddWithValue("@Descripcion", item.Descripcion);
                            command.Parameters.AddWithValue("@Existencias", item.Existencias);
                            command.Parameters.AddWithValue("@Precio", item.Precio);

                            await command.ExecuteNonQueryAsync();
                        }
                    }
                }

                // Redirect to the same page to display updated data
                return RedirectToPage("/Inventario");
            }
            catch (Exception ex)
            {
                // Handle exceptions
                // Log the exception, display an error message, etc.
                Console.WriteLine(ex.Message);
                return StatusCode(500); // Internal Server Error
            }
        }
    }

    public class InventarioItem
    {
        public int IdProducto { get; set; }
        public int IdProveedor { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public int Existencias { get; set; }
        public decimal Precio { get; set; }
    }

}
