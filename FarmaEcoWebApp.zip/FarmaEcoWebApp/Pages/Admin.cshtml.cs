using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;


namespace FarmaEcoWebApp.Pages
{
    public class AdminModel : PageModel
    {
        private readonly IConfiguration _configuration;
        public string ErrorMessage { get; set; }
        public class InventarioItem
        {
            public int idProducto { get; set; }
            public int idProveedor { get; set; }
            public string nombre { get; set; }
            public string descripcion { get; set; }
            public int existencias { get; set; }
            public decimal precio { get; set; }
        }

        public class EmpleadoItem
        {
            public int idEmpleado { get; set; }
            public string nombreEmpleado { get; set; }
            public string telefono { get; set; }
            public string email { get; set; }
            public string rol { get; set; }
            public string contrase�a { get; set; }
        }

        public class PromocionItem
        {
            public int idPromocion { get; set; }
            public decimal descuento { get; set; }
        }

        public class MovimientoItem
        {
            public int idMovimiento { get; set; }
            public int idFactura { get; set; }
            public int idProducto { get; set; }
            public int ammount { get; set; }
        }

        public class ProveedorItem
        {
            public int idProveedor { get; set; }
            public string empresa { get; set; }
            public string nombreContacto { get; set; }
            public string telefono { get; set; }
            public string email { get; set; }
        }

        public class ClienteItem
        {
            public int idCliente { get; set; }
            public string nombreCliente { get; set; }
            public string telefono { get; set; }
            public string email { get; set; }
        }

        public class FacturaItem
        {
            public int idFactura { get; set; }
            public int idEmpleado { get; set; }
            public int idCliente { get; set; }
            public decimal Subtotal { get; set; }
            public int? idDescuento { get; set; } // Change to nullable int
            public decimal? Descuento { get; set; } // Change to nullable decimal
            public decimal Impuesto { get; set; }
            public decimal Total { get; set; }
            public DateTime Fecha { get; set; }
            public string Metodo { get; set; }
        }

        public AdminModel(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public List<InventarioItem> InventarioItems { get; set; }
        public List<EmpleadoItem> EmpleadosItems { get; set; }
        public List<PromocionItem> PromocionesItems { get; set; }
        public List<MovimientoItem> MovimientosItems { get; set; }
        public List<ProveedorItem> ProveedorItems { get; set; }
        public List<ClienteItem> ClientesItems { get; set; }
        public List<FacturaItem> FacturasItems { get; set; }

        public async Task<IActionResult> OnGetAsync()
        {
            var connectionString = _configuration.GetConnectionString("DefaultConnection");

            // Fetch data from the database for each table
            InventarioItems = await GetInventarioItems(connectionString);
            EmpleadosItems = await GetEmpleadosItems(connectionString);
            PromocionesItems = await GetPromocionesItems(connectionString);
            MovimientosItems = await GetMovimientosItems(connectionString);
            ProveedorItems = await GetProveedorItems(connectionString);
            ClientesItems = await GetClientesItems(connectionString);
            FacturasItems = await GetFacturasItems(connectionString);

            return Page();
        }

        // Fetch methods for each table
        private async Task<List<InventarioItem>> GetInventarioItems(string connectionString)
        {
            var items = new List<InventarioItem>();
            string query = "SELECT idProducto, idProveedor, nombre, descripcion, existencias, precio FROM INVENTARIO";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                await connection.OpenAsync();

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = await command.ExecuteReaderAsync())
                    {
                        while (reader.Read())
                        {
                            items.Add(new InventarioItem
                            {
                                idProducto = reader.GetInt32(0),
                                idProveedor = reader.GetInt32(1),
                                nombre = reader.GetString(2),
                                descripcion = reader.GetString(3),
                                existencias = reader.GetInt32(4),
                                precio = reader.GetDecimal(5)
                            });
                        }
                    }
                }
            }

            return items;
        }

        // Fetch method for Empleados table
        private async Task<List<EmpleadoItem>> GetEmpleadosItems(string connectionString)
        {
            var items = new List<EmpleadoItem>();
            string query = "SELECT idEmpleado, nombreEmpleado, telefono, email, rol, contrase�a FROM EMPLEADOS";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                await connection.OpenAsync();

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = await command.ExecuteReaderAsync())
                    {
                        while (reader.Read())
                        {
                            items.Add(new EmpleadoItem
                            {
                                idEmpleado = reader.GetInt32(0),
                                nombreEmpleado = reader.GetString(1),
                                telefono = reader.GetString(2),
                                email = reader.GetString(3),
                                rol = reader.GetString(4),
                                contrase�a = reader.GetString(5)
                            });
                        }
                    }
                }
            }

            return items;
        }

        // Fetch method for Promociones table
        private async Task<List<PromocionItem>> GetPromocionesItems(string connectionString)
        {
            var items = new List<PromocionItem>();
            string query = "SELECT idPromocion, descuento FROM PROMOCIONES";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                await connection.OpenAsync();

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = await command.ExecuteReaderAsync())
                    {
                        while (reader.Read())
                        {
                            items.Add(new PromocionItem
                            {
                                idPromocion = reader.GetInt32(0),
                                descuento = reader.GetDecimal(1)
                            });
                        }
                    }
                }
            }

            return items;
        }

        // Fetch method for Movimientos table
        private async Task<List<MovimientoItem>> GetMovimientosItems(string connectionString)
        {
            var items = new List<MovimientoItem>();
            string query = "SELECT idMovimiento, idFactura, idProducto, ammount FROM MOVIMIENTOS";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                await connection.OpenAsync();

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = await command.ExecuteReaderAsync())
                    {
                        while (reader.Read())
                        {
                            items.Add(new MovimientoItem
                            {
                                idMovimiento = reader.GetInt32(0),
                                idFactura = reader.GetInt32(1),
                                idProducto = reader.GetInt32(2),
                                ammount = reader.GetInt32(3)
                            });
                        }
                    }
                }
            }

            return items;
        }

        // Fetch method for Proveedor table
        private async Task<List<ProveedorItem>> GetProveedorItems(string connectionString)
        {
            var items = new List<ProveedorItem>();
            string query = "SELECT idProveedor, empresa, nombreContacto, telefono, email FROM PROVEEDOR";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                await connection.OpenAsync();

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = await command.ExecuteReaderAsync())
                    {
                        while (reader.Read())
                        {
                            items.Add(new ProveedorItem
                            {
                                idProveedor = reader.GetInt32(0),
                                empresa = reader.GetString(1),
                                nombreContacto = reader.GetString(2),
                                telefono = reader.GetString(3),
                                email = reader.GetString(4)
                            });
                        }
                    }
                }
            }

            return items;
        }

        // Fetch method for Clientes table
        private async Task<List<ClienteItem>> GetClientesItems(string connectionString)
        {
            var items = new List<ClienteItem>();
            string query = "SELECT idCliente, nombreCliente, telefono, email FROM CLIENTES";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                await connection.OpenAsync();

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = await command.ExecuteReaderAsync())
                    {
                        while (reader.Read())
                        {
                            items.Add(new ClienteItem
                            {
                                idCliente = reader.GetInt32(0),
                                nombreCliente = reader.GetString(1),
                                telefono = reader.GetString(2),
                                email = reader.GetString(3)
                            });
                        }
                    }
                }
            }

            return items;
        }

        // Fetch method for Facturas table
        private async Task<List<FacturaItem>> GetFacturasItems(string connectionString)
        {
            var items = new List<FacturaItem>();
            string query = "SELECT idFactura, idEmpleado, idCliente, Subtotal, idDescuento, Descuento, Impuesto, Total, Fecha, Metodo FROM FACTURAS";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                await connection.OpenAsync();

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = await command.ExecuteReaderAsync())
                    {
                        while (reader.Read())
                        {
                            items.Add(new FacturaItem
                            {
                                idFactura = reader.GetInt32(0),
                                idEmpleado = reader.GetInt32(1),
                                idCliente = reader.GetInt32(2),
                                Subtotal = reader.GetDecimal(3),
                                idDescuento = reader.IsDBNull(4) ? null : (int?)reader.GetInt32(4),
                                Descuento = reader.IsDBNull(5) ? null : (decimal?)reader.GetDecimal(5),
                                Impuesto = reader.GetDecimal(6),
                                Total = reader.GetDecimal(7),
                                Fecha = reader.GetDateTime(8),
                                Metodo = reader.GetString(9)
                            });
                        }
                    }
                }
            }

            return items;
        }

        public async Task<IActionResult> OnPostAsync()
        {
            var connectionString = _configuration.GetConnectionString("DefaultConnection");

            // Save changes to the database
            await SaveChanges(connectionString);

            // Set the error message to be displayed in the alert
            TempData["ErrorMessage"] = ErrorMessage;

            // Redirect to the login page
            return RedirectToPage("/Admin");
        }



        // Method to save changes to the database
        private async Task SaveChanges(string connectionString)
        {

            try
            {

                using (SqlConnection connection = new SqlConnection(connectionString))
                {

                    await connection.OpenAsync();

                    // Begin a transaction
                    using (SqlTransaction transaction = connection.BeginTransaction())
                    {

                        try
                        {
                            var ItemCount = int.Parse(Request.Form["inventarioItemCount"]);

                            for (var i = 0; i < ItemCount; i++)
                            {

                                string query = @"UPDATE INVENTARIO SET
                                    idProveedor = @idProveedor,
                                    nombre = @nombre,
                                    descripcion = @descripcion,
                                    existencias = @existencias,
                                    precio = @precio
                                    WHERE idProducto = @idProducto;";

                                using (SqlCommand command = new SqlCommand(query, connection, transaction))
                                {
                                    command.Parameters.AddWithValue("@idProducto", Request.Form[$"InventarioItems[{i}].idProducto"].FirstOrDefault());
                                    command.Parameters.AddWithValue("@idProveedor", Request.Form[$"InventarioItems[{i}].idProveedor"].FirstOrDefault());
                                    command.Parameters.AddWithValue("@nombre", Request.Form[$"InventarioItems[{i}].nombre"].FirstOrDefault());
                                    command.Parameters.AddWithValue("@descripcion", Request.Form[$"InventarioItems[{i}].descripcion"].FirstOrDefault());
                                    command.Parameters.AddWithValue("@existencias", Request.Form[$"InventarioItems[{i}].existencias"].FirstOrDefault());
                                    command.Parameters.AddWithValue("@precio", Request.Form[$"InventarioItems[{i}].precio"].FirstOrDefault());
                                    await command.ExecuteNonQueryAsync();
                                }
                            }

                            ItemCount = int.Parse(Request.Form["empleadosItemCount"]);
                            // Save changes for Empleados table
                            for (var i = 0; i < ItemCount; i++)
                            {
                                string query = @"UPDATE EMPLEADOS SET
                    nombreEmpleado = @nombreEmpleado,
                    telefono = @telefono,
                    email = @email,
                    rol = @rol,
                    contrase�a = @contrase�a
                WHERE idEmpleado = @idEmpleado;";

                                using (SqlCommand command = new SqlCommand(query, connection, transaction))
                                {
                                    command.Parameters.AddWithValue("@idEmpleado", Request.Form[$"EmpleadosItems[{i}].idEmpleado"].FirstOrDefault());
                                    command.Parameters.AddWithValue("@nombreEmpleado", Request.Form[$"EmpleadosItems[{i}].nombreEmpleado"].FirstOrDefault());
                                    command.Parameters.AddWithValue("@telefono", Request.Form[$"EmpleadosItems[{i}].telefono"].FirstOrDefault());
                                    command.Parameters.AddWithValue("@email", Request.Form[$"EmpleadosItems[{i}].email"].FirstOrDefault());
                                    command.Parameters.AddWithValue("@rol", Request.Form[$"EmpleadosItems[{i}].rol"].FirstOrDefault());
                                    command.Parameters.AddWithValue("@contrase�a", Request.Form[$"EmpleadosItems[{i}].contrase�a"].FirstOrDefault());

                                    await command.ExecuteNonQueryAsync();
                                }
                            }

                            ItemCount = int.Parse(Request.Form["promocionesItemCount"]);
                            // Save changes for Empleados table
                            for (var i = 0; i < ItemCount; i++)
                            {
                                string query = @"UPDATE PROMOCIONES 
                SET descuento = @descuento
                WHERE idPromocion = @idPromocion;";

                                using (SqlCommand command = new SqlCommand(query, connection, transaction))
                                {
                                    command.Parameters.AddWithValue("@idPromocion", Request.Form[$"PromocionesItems[{i}].idPromocion"].FirstOrDefault());
                                    command.Parameters.AddWithValue("@descuento", Request.Form[$"PromocionesItems[{i}].descuento"].FirstOrDefault());

                                    await command.ExecuteNonQueryAsync();
                                }
                            }

                            ItemCount = int.Parse(Request.Form["movimientosItemCount"]);
                            // Save changes for Empleados table
                            for (var i = 0; i < ItemCount; i++)
                            {
                                string query = @"UPDATE MOVIMIENTOS 
                                SET idFactura = @idFactura, idProducto = @idProducto, ammount = @amount 
                                WHERE idMovimiento = @idMovimiento;";

                                using (SqlCommand command = new SqlCommand(query, connection, transaction))
                                {
                                    command.Parameters.AddWithValue("@idMovimiento", Request.Form[$"MovimientosItems[{i}].idMovimiento"].FirstOrDefault());
                                    command.Parameters.AddWithValue("@idFactura", Request.Form[$"MovimientosItems[{i}].idFactura"].FirstOrDefault());
                                    command.Parameters.AddWithValue("@idProducto", Request.Form[$"MovimientosItems[{i}].idProducto"].FirstOrDefault());
                                    command.Parameters.AddWithValue("@amount", Request.Form[$"MovimientosItems[{i}].Amount"].FirstOrDefault());

                                    await command.ExecuteNonQueryAsync();
                                }
                            }

                            ItemCount = int.Parse(Request.Form["proveedoresItemCount"]);
                            // Save changes for Empleados table
                            for (var i = 0; i < ItemCount; i++)
                            {
                                string query = @"UPDATE PROVEEDOR 
                                SET empresa = @empresa, nombreContacto = @nombreContacto, telefono = @telefono, email = @email 
                                WHERE idProveedor = @idProveedor;";

                                using (SqlCommand command = new SqlCommand(query, connection, transaction))
                                {
                                    command.Parameters.AddWithValue("@idProveedor", Request.Form[$"ProveedorItems[{i}].idProveedor"].FirstOrDefault());
                                    command.Parameters.AddWithValue("@empresa", Request.Form[$"ProveedorItems[{i}].empresa"].FirstOrDefault());
                                    command.Parameters.AddWithValue("@nombreContacto", Request.Form[$"ProveedorItems[{i}].nombreContacto"].FirstOrDefault());
                                    command.Parameters.AddWithValue("@telefono", Request.Form[$"ProveedorItems[{i}].telefono"].FirstOrDefault());
                                    command.Parameters.AddWithValue("@email", Request.Form[$"ProveedorItems[{i}].email"].FirstOrDefault());

                                    await command.ExecuteNonQueryAsync();
                                }
                            }

                            ItemCount = int.Parse(Request.Form["clientesItemCount"]);
                            // Save changes for Empleados table
                            for (var i = 0; i < ItemCount; i++)
                            {
                                string query = @"UPDATE CLIENTES 
                                SET nombreCliente = @nombreCliente, telefono = @telefono, email = @email 
                                WHERE idCliente = @idCliente;
                                ";

                                using (SqlCommand command = new SqlCommand(query, connection, transaction))
                                {
                                    command.Parameters.AddWithValue("@idCliente", Request.Form[$"ClientesItems[{i}].idCliente"].FirstOrDefault());
                                    command.Parameters.AddWithValue("@nombreCliente", Request.Form[$"ClientesItems[{i}].nombreCliente"].FirstOrDefault());
                                    command.Parameters.AddWithValue("@telefono", Request.Form[$"ClientesItems[{i}].telefono"].FirstOrDefault());
                                    command.Parameters.AddWithValue("@email", Request.Form[$"ClientesItems[{i}].email"].FirstOrDefault());

                                    await command.ExecuteNonQueryAsync();
                                }
                            }

                            ItemCount = int.Parse(Request.Form["facturasItemCount"]);
                            // Save changes for Empleados table
                            for (var i = 0; i < ItemCount; i++)
                            {
                                string query = @"UPDATE FACTURAS 
                                SET idEmpleado = @idEmpleado, 
                                    idCliente = @idCliente, 
                                    Subtotal = @Subtotal, 
                                    idDescuento = @idDescuento, 
                                    Descuento = @Descuento, 
                                    Impuesto = @Impuesto, 
                                    Total = @Total, 
                                    Fecha = @Fecha, 
                                    Metodo = @Metodo
                                WHERE idFactura = @idFactura;
                                ";

                                using (SqlCommand command = new SqlCommand(query, connection, transaction))
                                {
                                    command.Parameters.AddWithValue("@idFactura", Request.Form[$"FacturasItems[{i}].idFactura"].FirstOrDefault());
                                    command.Parameters.AddWithValue("@idEmpleado", Request.Form[$"FacturasItems[{i}].idEmpleado"].FirstOrDefault());
                                    command.Parameters.AddWithValue("@idCliente", Request.Form[$"FacturasItems[{i}].idCliente"].FirstOrDefault());
                                    command.Parameters.AddWithValue("@Subtotal", Request.Form[$"FacturasItems[{i}].Subtotal"].FirstOrDefault());
                                    command.Parameters.AddWithValue("@idDescuento", (object)Request.Form[$"FacturasItems[{i}].idDescuento"].FirstOrDefault() ?? DBNull.Value); // Handle nullable values
                                    command.Parameters.AddWithValue("@Descuento", (object)Request.Form[$"FacturasItems[{i}].Descuento"].FirstOrDefault() ?? DBNull.Value); // Handle nullable values
                                    command.Parameters.AddWithValue("@Impuesto", Request.Form[$"FacturasItems[{i}].Impuesto"].FirstOrDefault());
                                    command.Parameters.AddWithValue("@Total", Request.Form[$"FacturasItems[{i}].Total"].FirstOrDefault());
                                    command.Parameters.AddWithValue("@Fecha", Request.Form[$"FacturasItems[{i}].Fecha"].FirstOrDefault());
                                    command.Parameters.AddWithValue("@Metodo", Request.Form[$"FacturasItems[{i}].M�todo"].FirstOrDefault());

                                    await command.ExecuteNonQueryAsync();
                                }
                            }
                            // Commit the transaction if everything succeeds
                            transaction.Commit();
                            ErrorMessage = "Transaction successful";
                        }
                        catch (Exception ex)
                        {
                            ErrorMessage = $"Error occurred while saving changes: {ex.Message}";
                            // Rollback the transaction in case of an exception
                            transaction.Rollback();
                            throw; // Rethrow the exception to be handled in the calling code
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.Write(ex.Message);

                // Log the exception or handle it accordingly
                ErrorMessage = $"Error occurred while saving changes: {ex.Message}";
            }
        }
    }
}
