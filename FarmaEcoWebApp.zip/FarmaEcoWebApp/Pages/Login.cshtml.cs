using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;

namespace FarmaEcoWebApp.Pages
{
    public class LoginModel : PageModel
    {
        private readonly IConfiguration _configuration;

        public LoginModel(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [BindProperty]
        public int idEmpleado { get; set; }
        [BindProperty]
        public string contrase�a { get; set; }
        public string ErrorMessage { get; set; }

        public async Task<IActionResult> OnPostAsync()
        {
            var connectionString = _configuration.GetConnectionString("DefaultConnection");

            string query = $"SELECT rol FROM EMPLEADOS WHERE idEmpleado = @idEmpleado AND contrase�a = @contrase�a";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                await connection.OpenAsync();

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@idEmpleado", idEmpleado);
                    command.Parameters.AddWithValue("@contrase�a", contrase�a);

                    using (SqlDataReader reader = await command.ExecuteReaderAsync())
                    {
                        if (reader.Read())
                        {
                            string rol = reader.GetString(0);
                            switch (rol)
                            {
                                case "Administrador":
                                    return RedirectToPage("/Admin");
                                case "Facturador":
                                    return RedirectToPage("/Facturador", new { idEmpleado = idEmpleado });
                                case "Inventario":
                                    return RedirectToPage("/Inventario");
                                default:
                                    // Handle other roles
                                    break;
                            }
                        }
                        else
                        {
                            // Invalid login credentials
                            ErrorMessage = "Identificaci�n y/o contrase�a inv�lida(s)";
                            return Page();
                        }
                    }
                }
            }

            // Invalid login credentials
            ErrorMessage = "Identificaci�n y/o contrase�a inv�lida(s)";
            return Page();
        }
    }
}
